<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ValidSQLCastOperations
 *
 * @author Dan Kottke
 */
class ValidSQLCastOperations {
    const CONVERT = 'CONVERT';
    const CAST = 'CAST';
}

?>
