<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ValidSQLComparisonOperations
 *
 * @author Dan Kottke
 */
class ValidSQLComparisonOperations {
    
    const _AND = 'AND';
    const _OR = 'OR';
    const _XOR = 'XOR';
    const BETWEEN_AND = 'BETWEEN_AND';
    const COALESCE = 'COALESCE';
    const NULLSAFE_EQUALS = '<=>';
    const EQUALS = '=';
    const GREATER_THAN_OR_EQUALS = '>=';
    const GREATER_THAN = '>';
    const GREATEST = 'GREATEST';
    const IN = 'IN';
    const INTERVAL = 'INTERVAL';
    const IS_NOT_NULL = 'IS NOT NULL';
    const IS_NOT = 'IS NOT';
    const IS_NULL = 'IS NULL';
    const IS = 'IS';
    const ISNULL = 'ISNULL';
    const LEAST = 'LEAST';
    const LESS_THAN_OR_EQUALS = '<=';
    const LESS_THAN = '<';
    const LIKE = 'LIKE';
    const NOT_BETWEEN_AND = 'NOT_BETWEEN_AND';
    const NOT_EQUAL = '!=';
    const NOT_IN = 'NOT IN';
    const NOT_LIKE = 'NOT LIKE';
    const STRCMP = 'STRCMP';

}

?>
