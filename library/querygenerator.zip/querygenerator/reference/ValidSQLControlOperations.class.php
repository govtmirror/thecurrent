<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ValidSQLControlOperations
 *
 * @author Dan Kottke
 */
class ValidSQLControlOperations {
    const CASE_X_WHEN_THEN_ELSE = 'CASE_X_WHEN_THEN_ELSE';
    const CASE_WHEN_THEN_ELSE = 'CASE_WHEN_THEN_ELSE';
    
}

?>
