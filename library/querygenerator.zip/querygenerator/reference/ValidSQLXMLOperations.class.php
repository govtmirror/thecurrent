<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ValidSQLXMLOperations
 *
 * @author Dan Kottke
 */
class ValidSQLXMLOperations {
    const EXTRACTVALUE = "ExtractValue";
    const UPDATEXML = 'UpdateXML';
}

?>
