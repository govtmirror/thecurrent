<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ValidSQLMiscOperations
 *
 * @author Dan Kottke
 */
class ValidSQLMiscOperations {
    
    
    
    
    const FOUND_ROWS = 'FOUND_ROWS';	
    const LAST_INSERT_ID = 'LAST_INSERT_ID';
    const ROW_COUNT = 'ROW_COUNT';
    
}

?>
