<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ValidQueryConstantParameters
 *
 * @author Dan Kottke
 */
class ValidQueryConstantParameters {
    const VALUE = 0;
}

?>
