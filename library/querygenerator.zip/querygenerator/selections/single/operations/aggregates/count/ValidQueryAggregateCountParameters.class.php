<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ValidQueryAggregateCountParameters
 *
 * @author Dan Kottke
 */
class ValidQueryAggregateCountParameters {
    const DISTINCT = 0;
}

?>
