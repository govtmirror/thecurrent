<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ValidQueryAggregateCountExpressions
 *
 * @author Dan Kottke
 */
class ValidQueryAggregateCountExpressions {
    const EXP1 = 0;
}

?>
