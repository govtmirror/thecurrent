<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ValidQueryConditionExpressions
 *
 * @author Dan Kottke
 */
class ValidQueryConditionExpressions {
    const PRIMARY = 0;
    const SECONDARY = 1;
    //const TERTIARY = 2;
}

?>
