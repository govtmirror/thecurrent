<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ValidQueryContitionParameters
 *
 * @author Dan Kottke
 */
class ValidQueryConditionParameters {
    const OPERATION = 0;
    //const SET = 1;
}

?>
