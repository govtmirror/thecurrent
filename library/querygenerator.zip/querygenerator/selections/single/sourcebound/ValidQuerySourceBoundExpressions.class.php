<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ValidQueryTableBoundExpressions
 *
 * @author Dan Kottke
 */
class ValidQuerySourceBoundExpressions {
    const SOURCE = 0;
}

?>
