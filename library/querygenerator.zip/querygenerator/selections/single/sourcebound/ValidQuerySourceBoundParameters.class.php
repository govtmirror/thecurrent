<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ValidQueryTableBoundParameters
 *
 * @author Dan Kottke
 */
class ValidQuerySourceBoundParameters {
    const NAME = 0;
    
}

?>
