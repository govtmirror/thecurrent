<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ValidQueryOrderDirections
 *
 * @author KottkeDP
 */
class ValidQueryOrderDirections {
    const ASC = "ASC";
    const DESC = "DESC";
}

?>
