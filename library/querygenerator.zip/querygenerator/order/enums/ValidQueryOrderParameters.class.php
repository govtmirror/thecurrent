<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ValidQueryOrderDirections
 *
 * @author KottkeDP
 */
class ValidQueryOrderParameters {
    const DIRECTION = 0;
}

?>
