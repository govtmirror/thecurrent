<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ValidSQLInventoryParams
 *
 * @author Dan Kottke
 */
class ValidSQLVerifyParams {
    const CONNECTION = 'CONNECTION';
    //const AGGREGATE_COLUMNS = 'AGGREGATE_COLUMNS';
    //const NONAGGREGATE_COLUMNS = 'NONAGGREGATE_COLUMNS';
}

?>
