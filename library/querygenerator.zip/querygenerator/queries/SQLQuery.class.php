<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of SQLQuery
 *
 * @author Dan Kottke
 */
abstract class SQLQuery extends QueryElementValue{
    //put your code here
}

?>
