<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ValidQuerySetOperations
 *
 * @author KottkeDP
 */
class ValidQuerySetOperations {
    const UNION = 0;
    const INTERSECT = 1;
    const MINUS = 2;
    const EXCEPT = 3;
    
    const UNION_ALL = 4;
}

?>
