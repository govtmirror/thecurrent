<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ValidQueryExpressions
 *
 * @author Dan Kottke
 */
class ValidQueryExpressions {
    const SOURCE = 0;
    const SOURCELIST = 1;
    
    const SELECTIONS = 2;
    const JOINED_SOURCES = 3;
    const CONDITION = 4;
    const GROUP_BY = 5;
    const HAVING = 6;
    const ORDER_BY = 7;
    
    //const JOINED_SOURCES = 1;
    //const CONDITION = 2;
    //const ORDER_BY = 5;
    
    //const SELECTIONS = 0;
    const QUERY = 8;
    
    //const SELECTIONS = 0;
    const VALUES = 9;
    
    const IGNITION = 10;
    
    const COMPLETION = 11;
    
    //const SELECTIONS = 0;
    //const JOINED_SOURCES = 1;
    //const CONDITION = 2; 
    //const VALUES = 3;
    //const ORDER_BY = 5;
    
}

?>
