<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ValidQueryDatabaseFormats
 *
 * @author Dan Kottke
 */
class ValidQueryDatabaseFormats {
    const MYSQL = "MySQL";
}

?>
