<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ValidQueryParameters
 *
 * @author Dan Kottke
 */
class ValidQueryParameters {
    const DEFAULT_DB = 0;
    const DATABASE_TYPE = 1;
    
    const IS_DISTINCT = 2;
    const INTO = 3;
    const LIMIT = 4;
    
    const SET_OPERATION = 5;
}

?>
