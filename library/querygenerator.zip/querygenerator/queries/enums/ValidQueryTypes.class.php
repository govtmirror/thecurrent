<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ValidQueryTypes
 *
 * @author KottkeDP
 */
class ValidQueryTypes {
    const SELECT = "SELECT";
    const UPDATE = "UPDATE";
    const DELETE = "DELETE";
    const INSERT_SELECT = "INSERTSELECT";
    const INSERT_VALUE = "INSERTVALUE";
}

?>
