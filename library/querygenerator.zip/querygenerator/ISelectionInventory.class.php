<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of 
 *
 * @author KottkeDP
 */
interface ISelectionInventory {
    public function get_inventory($param = null);
    //public function lookup();
    
    
}

?>
