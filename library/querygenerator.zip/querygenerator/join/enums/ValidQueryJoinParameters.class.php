<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ValidQuerySelectJoinParameters
 *
 * @author KottkeDP
 */
class ValidQueryJoinParameters {
    const JOIN_TYPE = 0;
     
}

?>
