<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ValidSelectJoinExpressions
 *
 * @author KottkeDP
 */
class ValidQueryJoinExpressions {
    const SOURCE = 0;
    const LOCAL_SELECTION = 1;
    const FOREIGN_SELECTION = 2;
}

?>
