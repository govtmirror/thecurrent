<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ValidQuerySelectionJoinTypes
 *
 * @author KottkeDP
 */
class ValidQueryJoinTypes {
    const INNER = "INNER JOIN";
    const LEFT  = "LEFT JOIN";
    const RIGHT = "RIGHT JOIN";
    
    const CROSS = "CROSS JOIN";
    
    //const NATURAL = "NATURAL JOIN";
}

?>
