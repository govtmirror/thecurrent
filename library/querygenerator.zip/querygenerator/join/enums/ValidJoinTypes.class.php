<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ValidJoinTypes
 *
 * @author KottkeDP
 */
class ValidJoinTypes {
    
    const JOIN = 'JOIN';
    const INNER_JOIN = 'INNER JOIN';
    const LEFT_JOIN = 'LEFT JOIN';
    const RIGHT_JOIN = 'RIGHT JOIN';
    const CROSS_JOIN = 'CROSS JOIN';
    
}

?>
