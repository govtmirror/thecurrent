<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ValidQueryToSQLParameters
 *
 * @author Dan Kottke
 */
class ValidQueryToSQLParameters {
    
    const FORMAT = 0;
    const PARENTHESIS = 1;
    const REGION = 2;
    const FRAGMENT = 3;
    
}

?>
