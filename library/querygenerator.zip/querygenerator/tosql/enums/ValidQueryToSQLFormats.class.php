<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ValidQueryToSQLFormats
 *
 * @author Dan Kottke
 */
class ValidQueryToSQLFormats {
    const STANDARD = 0;
    const ALIAS = 1;
    const DEFINITION = 2;
}

?>
