<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ValidQueryMySQLTableExpressions
 *
 * @author KottkeDP
 */
class ValidQueryMySQLTableExpressions {
    
    const COLUMNS = 1;
    
}

?>
