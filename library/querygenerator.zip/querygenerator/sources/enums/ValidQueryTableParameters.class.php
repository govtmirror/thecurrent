<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ValidQueryTableParameters
 *
 * @author Dan Kottke
 */
class ValidQueryTableParameters {
    const NAME = 0;
    const DATABASE = 1;
}

?>
